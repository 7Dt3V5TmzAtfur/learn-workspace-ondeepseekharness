# -*- coding: utf-8 -*-
"""
深度阅读 HTML 统一后处理脚本（通用版，无第三方依赖，仅用 Python 标准库）。

作用（对指定目录/文件中的所有 .html）：
1. 重建统一 <head>（Mermaid base 主题 + 页脚页码 + 精修打印 CSS）。
2. 把残留的 <pre class="code">```mermaid ...```</pre> 转成 <div class="mermaid">，真正渲染。
3. 反转义 <div class="mermaid"> 内的 HTML 实体（&lt; &gt; &amp;），保证 <br/>、--> 可解析。

用法：
    python _postprocess.py                # 处理“本脚本所在目录”下的所有 .html
    python _postprocess.py 某目录         # 处理该目录下的所有 .html
    python _postprocess.py 某文件.html    # 只处理这一个文件

跨项目使用：把本脚本与 可视化阅读文字_Prompt.md、_validate.mjs 一起拷到新项目即可，
无需改动任何路径。
"""
import os, re, html, glob, sys

HEAD = """<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>__TITLE__</title>
<script src="https://cdn.jsdelivr.net/npm/mermaid@10/dist/mermaid.min.js"></script>
<script>
mermaid.initialize({
  startOnLoad: true,
  securityLevel: 'loose',
  theme: 'base',
  themeVariables: {
    fontFamily: '"Noto Serif SC","Songti SC","SimSun","宋体",serif',
    fontSize: '15px',
    primaryColor: '#eaf0f6',
    primaryBorderColor: '#2f5b7c',
    primaryTextColor: '#17364d',
    lineColor: '#5a6b7b',
    secondaryColor: '#f6efe3',
    secondaryBorderColor: '#a08c5b',
    secondaryTextColor: '#4a3d1f',
    tertiaryColor: '#e9f2ea',
    tertiaryBorderColor: '#5b8a5b',
    tertiaryTextColor: '#1f4a1f',
    edgeLabelBackground: '#ffffff',
    clusterBkg: '#f4f7fa',
    clusterBorder: '#c3cdd6',
    titleColor: '#17364d'
  },
  flowchart: { curve: 'basis', htmlLabels: true, useMaxWidth: true }
});
</script>
<style>
  @page { size: A4; margin: 2cm;
    @bottom-center { content: counter(page) " / " counter(pages);
      font-family: "Noto Sans SC","Microsoft YaHei",sans-serif; font-size: 9pt; color: #999; }
  }
  * { box-sizing: border-box; }
  html { -webkit-print-color-adjust: exact; print-color-adjust: exact; }
  body { background:#ffffff; color:#1a1a1a;
    font-family:"Noto Serif SC","Songti SC","SimSun","宋体",serif;
    font-size:12pt; line-height:1.8; margin:0; padding:0; text-align:justify; }
  h1 { font-family:"Noto Sans SC","Microsoft YaHei","PingFang SC",sans-serif;
    font-size:20pt; text-align:center; margin:0 0 1em; padding-bottom:.35em;
    border-bottom:3px double #2f5b7c; color:#17364d; letter-spacing:.02em; }
  h2 { font-family:"Noto Sans SC","Microsoft YaHei","PingFang SC",sans-serif;
    font-size:15pt; margin:1.5em 0 .6em; padding:.25em .6em;
    border-left:5px solid #2f5b7c; background:#f2f6fa; color:#17364d; }
  h3 { font-family:"Noto Sans SC","Microsoft YaHei","PingFang SC",sans-serif;
    font-size:13pt; margin:1.2em 0 .5em; color:#2f5b7c; }
  .article-content p { text-indent:2em; margin:.55em 0; }
  .article-content blockquote { border-left:3px solid #b9c6d2; background:#f7f9fb;
    padding:.6em 1em; margin:.9em 0; color:#33414d; }
  .article-content blockquote p { text-indent:0; margin:.3em 0; }
  hr { border:none; border-top:1px solid #d5dde3; margin:1.3em 0; }
  table { border-collapse:collapse; width:100%; margin:1em 0; font-size:10.5pt; }
  table th, table td { border:1px solid #c3cdd6; padding:5px 9px; text-align:left; vertical-align:top; }
  table th { background:#eaf0f6; font-weight:700; color:#17364d; }
  .code { background:#f5f6f7; border:1px solid #d0d6db; border-radius:4px; padding:10px 12px;
    font-family:Consolas,"Courier New",monospace; font-size:9.5pt; line-height:1.5;
    white-space:pre; overflow-x:auto; margin:.8em 0; }
  .mermaid { margin:1.2em auto; text-align:center; page-break-inside:avoid; }
  .mermaid svg { max-width:100%; height:auto; }
  ol.guide { padding-left:1.7em; }
  ol.guide li { margin:.9em 0; text-indent:0; }
  .c-red{color:#c0392b;font-weight:700}
  .c-blue{color:#1f5fb0;font-weight:700}
  .c-yellow{color:#b8860b;font-weight:700}
  .c-green{color:#1e7d34;font-weight:700}
  .new-page{page-break-before:always}
</style>
</head>"""

PRE_RE = re.compile(r'<pre class="code">\s*```mermaid\s*(.*?)```\s*</pre>', re.DOTALL)
TITLE_RE = re.compile(r'<title>(.*?)</title>', re.DOTALL)
HEAD_RE = re.compile(r'<head>.*?</head>', re.DOTALL)
DIV_MERMAID_RE = re.compile(r'(<div class="mermaid">)(.*?)(</div>)', re.DOTALL)

def convert_pre_mermaid(content):
    def repl(m):
        code = html.unescape(m.group(1)).strip()
        return '<div class="mermaid">\n' + code + '\n</div>'
    return PRE_RE.sub(repl, content)

def unescape_div_mermaid(content):
    def repl(m):
        return m.group(1) + html.unescape(m.group(2)) + m.group(3)
    return DIV_MERMAID_RE.sub(repl, content)

def process(path):
    with open(path, 'r', encoding='utf-8') as f:
        content = f.read()
    mt = TITLE_RE.search(content)
    title = mt.group(1).strip() if mt else os.path.splitext(os.path.basename(path))[0] + ' · 深度阅读'
    if HEAD_RE.search(content):
        content = HEAD_RE.sub(HEAD.replace('__TITLE__', title), content)
    else:
        content = content.replace('<html>', '<html>\n' + HEAD.replace('__TITLE__', title), 1)
    n_pre = len(PRE_RE.findall(content))
    content = convert_pre_mermaid(content)
    content = unescape_div_mermaid(content)
    n_div = len(DIV_MERMAID_RE.findall(content))
    with open(path, 'w', encoding='utf-8') as f:
        f.write(content)
    return os.path.basename(path), n_pre, n_div

def collect_targets(arg):
    if arg is None:
        arg = os.path.dirname(os.path.abspath(__file__))
    if os.path.isfile(arg):
        return [arg] if arg.lower().endswith('.html') else []
    if os.path.isdir(arg):
        return sorted(glob.glob(os.path.join(arg, '*.html')))
    print('路径不存在:', arg); return []

if __name__ == '__main__':
    arg = sys.argv[1] if len(sys.argv) > 1 else None
    files = collect_targets(arg)
    print('目标:', arg or '(脚本所在目录)', '| 发现 html 文件 %d 个' % len(files))
    for p in files:
        name, n_pre, n_div = process(p)
        print('fixed: %-45s pre_mermaid=%d  total_mermaid_divs=%d' % (name, n_pre, n_div))
    print('done')
