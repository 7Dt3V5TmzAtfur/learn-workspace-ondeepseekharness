// 深度阅读 HTML 的 Mermaid 权威语法校验脚本（通用版，Node + mermaid + jsdom）。
//
// 作用：对指定目录/文件中的所有 .html，逐个提取 <div class="mermaid"> 图，
//       用真实 Mermaid 解析器 mermaid.parse() 校验，报告任何语法错误。
//
// 依赖（首次使用前，在“本脚本所在目录”执行一次）：
//       npm install mermaid@10 jsdom
//   （会生成 node_modules，可随时删除后重装；跨项目拷贝脚本后同样先装依赖再运行）
//
// 用法：
//       node _validate.mjs                 # 校验“当前目录”下的所有 .html
//       node _validate.mjs 某目录          # 校验该目录下的所有 .html
//       node _validate.mjs 某文件.html     # 只校验这一个文件
import { JSDOM } from 'jsdom';
import fs from 'fs';
import path from 'path';

const dom = new JSDOM('<!DOCTYPE html><html><body></body></html>', { url: 'http://localhost/' });
global.window = dom.window;
global.document = dom.window.document;
// Node 18+ 的 navigator 是只读全局，需用 defineProperty 注入
Object.defineProperty(global, 'navigator', { value: dom.window.navigator, configurable: true, writable: true });
global.Element = dom.window.Element;
global.HTMLElement = dom.window.HTMLElement;
global.SVGElement = dom.window.SVGElement;
global.getComputedStyle = dom.window.getComputedStyle;
global.DOMParser = dom.window.DOMParser;
global.XMLSerializer = dom.window.XMLSerializer;

const mermaid = (await import('mermaid')).default;
mermaid.initialize({ startOnLoad: false, securityLevel: 'loose', theme: 'base' });

const target = process.argv[2] || process.cwd();
let files = [];
if (fs.existsSync(target) && fs.statSync(target).isFile()) {
  if (target.toLowerCase().endsWith('.html')) files = [target];
} else if (fs.existsSync(target)) {
  files = fs.readdirSync(target).filter(f => f.endsWith('.html')).map(f => path.join(target, f)).sort((a, b) => a.localeCompare(b, 'zh'));
} else {
  console.log('路径不存在:', target);
  process.exit(1);
}

let totalErr = 0, totalOk = 0;
for (const f of files) {
  const html = fs.readFileSync(f, 'utf8');
  const blocks = [...html.matchAll(/<div class="mermaid">([\s\S]*?)<\/div>/g)].map(m => m[1]);
  for (let i = 0; i < blocks.length; i++) {
    const src = blocks[i].trim();
    try {
      await mermaid.parse(src);
      totalOk++;
    } catch (e) {
      totalErr++;
      const msg = (e && e.message ? e.message : String(e)).split('\n')[0];
      console.log('ERR  ' + path.basename(f) + '  块' + i + ': ' + msg);
      console.log('     源首行: ' + src.split('\n').slice(0, 3).join(' | '));
    }
  }
}
console.log('----------------------------------------');
console.log('文件 ' + files.length + ' 个 | 通过 ' + totalOk + ' 张 | 语法错误 ' + totalErr + ' 张');
if (totalErr > 0) process.exit(2);
